import Foundation
import UIKit

public class FalandoComMongeCumprimentando: UIViewController{
    
    let fundoMonge = UIImageView()
    let monge = UIImageView()
    let passaros = UIImageView()
    let fraseExplicando = UIImageView()
    let botaoVoltarChina = UIButton()
    
    let falaCumprimentar = UIImageView()
    
    let botaoProximo =  UIButton()
    let botaoVoltar = UIButton()
    var botaoPressionado: Int = 0
    
    
    override public func loadView(){
        
        let viewChina = UIView()
        self.view = viewChina
        
        
    }
}
