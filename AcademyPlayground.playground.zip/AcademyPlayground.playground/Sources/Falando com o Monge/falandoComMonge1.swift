import UIKit

public class FalandoComMonge: UIViewController{


    let fundoMonge = UIImageView()
    let monge = UIImageView()
    let passaros = UIImageView()
    let fraseExplicando = UIImageView()
    let botaoVoltarChina = UIButton()

    let botao1 = UIButton()
    let botao2 = UIButton()
    let botao3 = UIButton()
    
    let falaCumprimentar = UIImageView()
    let falaCareca = UIImageView()
    
    let botaoProximo =  UIButton()
    let botaoVoltar = UIButton()
    var botaoPressionado: Int = 0
    
    var acoesBoop: [AcaoBoop] = [AcaoBoop(titulo:"Cumprimentar", falaBoop: "Olá, sou Boop. Está tudo bem? Vi você aqui em cima dessa montanha sozinho e queria sabe se está tudo bem..." ,falaMonge:  "Olá Boop! Está tudo bem sim, estou sozinho porque eu estava meditando."),
    AcaoBoop(titulo:"FALA2",falaBoop:  "o bem..." ,falaMonge:  "OIOIo."),
    AcaoBoop(titulo: "FALA3", falaBoop: "XAUXAU." , falaMonge: "OI"),
    AcaoBoop(titulo: "DASDADA", falaBoop: "Olá, sou Boop. Está tudo bem? Vi você aqui em cima dessa montanha sozinho e queria sabe se está tudo bem..." , falaMonge: "OÜLTIMAo.")
    ]
    
    
    @IBAction func escolherOpcao(sender: UIButton){
        
        
        
    }
    
    @objc func tocarBotaoVoltarTudo() {
        print("foi para a casa")
        let novaViewController = OnboardingChina()
        show(novaViewController, sender: nil)
    }
    
//
//    @objc func tocarCumprimentarOuSozinho() {
//        print("cumprimentou ou perguntar pq ta sozinho")
//        self.cumprimentar.isHidden = true
//        let novaViewController = FalandoComMongeCumprimentando()
//        show(novaViewController, sender: nil)
//        //colocar os contadores/tags, com uma propriedade ou variavel global p passar..
//
//    }
//
//    @objc func tocarCareca() {
//        print("tocou em pq ele eh careca")
//        self.cumprimentar.isHidden = true
//        let novaViewController = FalandoComMongeCareca()
//        show(novaViewController, sender: nil)
//        //colocar os contadores, caso o switch aqui
//
//    }
    
    
     override public func loadView(){
    
        let viewChina = UIView()
        self.view = viewChina
            
        fundoMonge.image = UIImage(named: "fundoMonge")
        fundoMonge.frame = CGRect(x: 0, y: 0, width: 1440, height: 900)
        
        monge.image = UIImage(named: "monge")
        monge.frame = CGRect(x: 1085, y: 172, width: 287, height: 356)
        
        passaros.image = UIImage(named: "passaros")
        passaros.frame = CGRect(x: 15, y: -28, width: 564, height: 390)
        
        fraseExplicando.image = UIImage(named: "oqBoopVaiFzr")
        fraseExplicando.frame = CGRect(x: 515, y: 656, width: 499, height: 150)
        //colcoar TIMER AQ
        
        botaoVoltarChina.frame = CGRect(x: 973, y: 504, width: 278, height: 93)
        botaoVoltarChina.setBackgroundImage(UIImage(named: "botaoEsquerdo"), for: .normal)

        botao1.frame = CGRect(x: 532, y: 39, width: 447, height: 93)
        botao1.isHidden = false
        
        botao2.frame = CGRect(x: 528, y: 149, width: 447, height: 93)
        botao2.isHidden = false
        
        botao3.frame = CGRect(x: 528, y: 259, width: 447, height: 93)
        botao3.isHidden = false
        
        falaCumprimentar.image = UIImage(named: "falaCumprimentar")
        falaCumprimentar.frame = CGRect(x: 409, y: 90, width: 610, height: 225)
        falaCumprimentar.isHidden = true
        
        falaCareca.image = UIImage(named: "falaCareca")
        falaCareca.frame = CGRect(x: 409, y: 90, width: 610, height: 225)
        falaCareca.isHidden = true
        
        botaoProximo.setBackgroundImage(UIImage(named: "setaDireita"), for: .normal)
        botaoProximo.frame = CGRect(x: 1000, y: 597, width: 57, height: 53)
        botaoProximo.tag = 1
        
        botaoVoltar.setBackgroundImage(UIImage(named: "botaoEsquerdo"), for: .normal)
        botaoVoltar.frame = CGRect(x: 901, y: 597, width: 57, height: 53)
        botaoVoltar.tag = 0
        botaoVoltar.isHidden = true
        
        botaoVoltarChina.setBackgroundImage(UIImage(named: "voltarChina"), for: .normal)
        botaoVoltarChina.frame = CGRect(x: 901, y: 597, width: 57, height: 53)
        
        
        viewChina.addSubview(fundoMonge)
        viewChina.addSubview(passaros)
        viewChina.addSubview(fraseExplicando)
        viewChina.addSubview(monge)
        viewChina.addSubview(botaoVoltarChina)
        viewChina.addSubview(botao1)
        viewChina.addSubview(botao2)
        viewChina.addSubview(botao3)
        
  
        
        botao1.addTarget(self, action: #selector(FalandoComMonge.escolherOpcao), for: .touchUpInside)
        botao2.addTarget(self, action: #selector(FalandoComMonge.escolherOpcao), for: .touchUpInside)
        botao3.addTarget(self, action: #selector(FalandoComMonge.escolherOpcao), for: .touchUpInside)
        botaoVoltarChina.addTarget(self, action: #selector(FalandoComMonge.tocarBotaoVoltarTudo), for: .touchUpInside)

        exibirOpcoes()

    }

    func exibirOpcoes(){
        botao1.titleLabel?.text = acoesBoop[0].titulo
        botao2.titleLabel?.text = acoesBoop[1].titulo
        botao3.titleLabel?.text = acoesBoop[2].titulo

    }
    
}

public class AcaoBoop{
    
    var titulo: String
    var falaBoop: String
    var falaMonge: String
    
    
    init(titulo:String, falaBoop:String, falaMonge:String){
        
        self.titulo = titulo
        self.falaBoop = falaBoop
        self.falaMonge = falaMonge
        
    }
    
    
    
    
}
